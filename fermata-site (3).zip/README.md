# Fermata website

Static site for فيرماتا. Edit `index.html` (settings are in the `CONFIG` block near the bottom). Images live in `images/`.
